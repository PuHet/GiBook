package com.test.gibook;

import com.google.android.gms.common.api.internal.IStatusCallback;

public class Posting {
    public String Name;
    public String Password;
    public String Title;
    public String Contents;
    public String Images;
    public String Status;
    public String Date;

    // 생성자
    public Posting(String name, String title, String password, String contents, String images, String status, String date) {
        this.Name = name;
        this.Title = title;
        this.Password = password;
        this.Contents = contents;
        this.Images = images;
        this.Status = status;
        this.Date = date;
    }

    public Posting() {

    }

}
